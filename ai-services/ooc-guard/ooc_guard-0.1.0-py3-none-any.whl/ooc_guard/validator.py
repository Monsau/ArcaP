"""
OOC-Guard validation orchestrator.

Runs the three-layer pipeline (syntax → semantic → shacl) and
returns a unified ValidationReport.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml  # PyYAML

from ooc_guard.layers.semantic import validate_semantic
from ooc_guard.layers.shacl import validate_shacl
from ooc_guard.layers.syntax import validate_syntax
from ooc_guard.models.report import (
    LayerStatus,
    OverallStatus,
    ValidationLayers,
    ValidationReport,
)


def _load_raw(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    with p.open(encoding="utf-8") as fh:
        if p.suffix in (".yaml", ".yml"):
            return yaml.safe_load(fh)
        return json.load(fh)


def validate(
    contract_path: str | Path,
    *,
    layer: str = "all",
    data_graph: str | None = None,
    reasoner: str = "hermit",
    strict: bool = False,
) -> ValidationReport:
    """
    Run the full OOC-Guard validation pipeline.

    Args:
        contract_path: Path to the OOC YAML/JSON file.
        layer:         "all" | "syntax" | "semantic" | "shacl"
        data_graph:    Path to RDF data file for SHACL layer.
        reasoner:      OWL reasoner: "hermit" | "pellet" | "rdflib".
        strict:        Treat sh:Warning as failure.

    Returns:
        ValidationReport with per-layer results and overall status.
    """
    raw = _load_raw(contract_path)
    contract_id = (
        raw.get("ontology_contract", {}).get("metadata", {}).get("id", "unknown")
    )
    contract_version = (
        raw.get("ontology_contract", {}).get("metadata", {}).get("version", "0.0.0")
    )

    layers = ValidationLayers()
    overall = OverallStatus.PASSED

    # ── Layer 1: Syntax ──────────────────────────────────────────────────────
    if layer in ("all", "syntax"):
        layers.syntax = validate_syntax(raw)
        if layers.syntax.status in (LayerStatus.FAILED, LayerStatus.ERROR):
            overall = OverallStatus.FAILED
            if layer == "all":
                # Hard gate: do not proceed if syntax fails
                return ValidationReport(
                    contract_id=contract_id,
                    contract_version=contract_version,
                    overall_status=overall,
                    layers=layers,
                )

    # ── Layer 2: Semantic ────────────────────────────────────────────────────
    if layer in ("all", "semantic"):
        layers.semantic = validate_semantic(raw, reasoner=reasoner)
        if layers.semantic.status in (LayerStatus.FAILED, LayerStatus.ERROR):
            overall = OverallStatus.FAILED
            if layer == "all":
                return ValidationReport(
                    contract_id=contract_id,
                    contract_version=contract_version,
                    overall_status=overall,
                    layers=layers,
                )

    # ── Layer 3: SHACL ───────────────────────────────────────────────────────
    if layer in ("all", "shacl"):
        layers.shacl = validate_shacl(raw, data_graph_source=data_graph, strict=strict)
        if layers.shacl.status in (LayerStatus.FAILED, LayerStatus.ERROR):
            overall = OverallStatus.FAILED

    return ValidationReport(
        contract_id=contract_id,
        contract_version=contract_version,
        overall_status=overall,
        layers=layers,
    )
