"""
Pydantic v2 models for the Operational Ontology Contract (OOC) format.
Base URI: https://ontology.arcaq.ai/schema/core#
"""

from __future__ import annotations

from enum import Enum
from typing import Annotated, Any

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class OntologyStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class PropertyType(str, Enum):
    OBJECT = "owl:ObjectProperty"
    DATATYPE = "owl:DatatypeProperty"
    ANNOTATION = "owl:AnnotationProperty"


class SHACLSeverity(str, Enum):
    INFO = "sh:Info"
    WARNING = "sh:Warning"
    VIOLATION = "sh:Violation"


class RevisionPolicy(str, Enum):
    OLM_SNAPSHOT = "OLM_Snapshot"
    SEMVER = "semver"
    DATE_TAGGED = "date-tagged"


class MappingType(str, Enum):
    EXACT = "skos:exactMatch"
    CLOSE = "skos:closeMatch"
    BROAD = "skos:broadMatch"
    NARROW = "skos:narrowMatch"
    EQUIVALENT_CLASS = "owl:equivalentClass"
    EQUIVALENT_PROPERTY = "owl:equivalentProperty"
    SAME_AS = "owl:sameAs"


# ---------------------------------------------------------------------------
# Governance
# ---------------------------------------------------------------------------

class Governance(BaseModel):
    domain: str
    owner: str
    contact: str | None = None
    review_cycle: str | None = None


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

class Metadata(BaseModel):
    id: str
    version: str
    base_uri: Annotated[str, Field(pattern=r"^https?://")]
    status: OntologyStatus = OntologyStatus.DRAFT
    created: str | None = None
    governance: Governance

    @field_validator("version")
    @classmethod
    def semver_format(cls, v: str) -> str:
        parts = v.split(".")
        if len(parts) != 3 or not all(p.isdigit() for p in parts):
            raise ValueError(f"version must be semver x.y.z, got: {v!r}")
        return v


# ---------------------------------------------------------------------------
# Semantics — Classes
# ---------------------------------------------------------------------------

class OntologyClass(BaseModel):
    name: str
    uri: str
    definition: str
    subclass_of: str | None = None
    equivalent_class: str | None = None
    labels: dict[str, str] = Field(default_factory=dict)

    @field_validator("labels")
    @classmethod
    def must_have_english(cls, v: dict[str, str]) -> dict[str, str]:
        if v and "en" not in v:
            raise ValueError("Every OOC class label block must include an 'en' entry.")
        return v


# ---------------------------------------------------------------------------
# Semantics — Properties
# ---------------------------------------------------------------------------

class OntologyProperty(BaseModel):
    name: str
    uri: str
    type: PropertyType = PropertyType.DATATYPE
    domain: str | None = None
    range: str | None = None
    characteristics: list[str] = Field(default_factory=list)
    allowed_values: list[str] | None = None
    labels: dict[str, str] = Field(default_factory=dict)


class Semantics(BaseModel):
    classes: list[OntologyClass] = Field(default_factory=list)
    properties: list[OntologyProperty] = Field(default_factory=list)

    @model_validator(mode="after")
    def no_duplicate_uris(self) -> "Semantics":
        uris: list[str] = [c.uri for c in self.classes] + [p.uri for p in self.properties]
        seen: set[str] = set()
        for u in uris:
            if u in seen:
                raise ValueError(f"Duplicate URI detected in semantics: {u!r}")
            seen.add(u)
        return self


# ---------------------------------------------------------------------------
# Data Integrity — SHACL Shapes
# ---------------------------------------------------------------------------

class SHACLConstraint(BaseModel):
    property: str
    min_count: int | None = None
    max_count: int | None = None
    datatype: str | None = None
    pattern: str | None = None
    in_values: list[str] | None = Field(None, alias="in")
    class_: str | None = Field(None, alias="class")
    language_in: list[str] | None = None
    message: str | None = None

    model_config = {"populate_by_name": True}


class SHACLShape(BaseModel):
    id: str | None = None
    target_class: str
    severity: SHACLSeverity = SHACLSeverity.VIOLATION
    constraints: list[SHACLConstraint] = Field(default_factory=list)


class DataIntegrity(BaseModel):
    shapes: list[SHACLShape] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Versioning Control
# ---------------------------------------------------------------------------

class VersioningControl(BaseModel):
    revision_policy: RevisionPolicy = RevisionPolicy.OLM_SNAPSHOT
    strategy: str = "append-only"
    immutable_attributes: list[str] = Field(default_factory=list)
    mutable_with_provenance: list[str] = Field(default_factory=list)
    snapshot_format: str = "Turtle+PROV-O"
    changelog_predicate: str = "dcterms:hasVersion"


# ---------------------------------------------------------------------------
# Federation
# ---------------------------------------------------------------------------

class OntologyImport(BaseModel):
    uri: Annotated[str, Field(pattern=r"^https?://")]
    alias: str


class AlignmentMapping(BaseModel):
    external_uri: Annotated[str, Field(pattern=r"^https?://")]
    mapping: MappingType
    rationale: str | None = None


class Federation(BaseModel):
    imports: list[OntologyImport] = Field(default_factory=list)
    alignment: list[AlignmentMapping] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Root — Operational Ontology Contract
# ---------------------------------------------------------------------------

class OntologyContract(BaseModel):
    metadata: Metadata
    semantics: Semantics = Field(default_factory=Semantics)
    data_integrity: DataIntegrity = Field(default_factory=DataIntegrity)
    versioning_control: VersioningControl = Field(default_factory=VersioningControl)
    federation: Federation = Field(default_factory=Federation)


class OOCDocument(BaseModel):
    """Top-level wrapper matching the OOC YAML root key."""
    ontology_contract: OntologyContract

    @classmethod
    def from_yaml(cls, path: str) -> "OOCDocument":
        import yaml  # optional dep — only needed at runtime

        with open(path, encoding="utf-8") as fh:
            raw: Any = yaml.safe_load(fh)
        return cls.model_validate(raw)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OOCDocument":
        return cls.model_validate(data)
