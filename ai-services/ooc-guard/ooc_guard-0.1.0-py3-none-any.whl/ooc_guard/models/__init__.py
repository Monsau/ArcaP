"""ooc_guard.models package."""
