"""Validation report models for OOC-Guard."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class LayerStatus(str, Enum):
    PASSED = "PASSED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    ERROR = "ERROR"


class OverallStatus(str, Enum):
    PASSED = "PASSED"
    FAILED = "FAILED"
    ERROR = "ERROR"


# ---------------------------------------------------------------------------
# Per-layer reports
# ---------------------------------------------------------------------------

class SyntaxViolation(BaseModel):
    field: str
    message: str
    value: Any = None


class SyntaxLayerReport(BaseModel):
    status: LayerStatus
    checks: int = 0
    violations: list[SyntaxViolation] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


class SemanticLayerReport(BaseModel):
    status: LayerStatus
    reasoner: str = "hermit"
    satisfiable_classes: int = 0
    unsatisfiable_classes: int = 0
    unsatisfiable_names: list[str] = Field(default_factory=list)
    inferred_triples: int = 0
    errors: list[str] = Field(default_factory=list)


class SHACLViolation(BaseModel):
    shape_id: str | None
    target_node: str
    property: str | None
    severity: str
    message: str


class SHACLLayerReport(BaseModel):
    status: LayerStatus
    shapes_evaluated: int = 0
    violations: int = 0
    warnings: int = 0
    infos: int = 0
    details: list[SHACLViolation] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Root validation report
# ---------------------------------------------------------------------------

class ValidationLayers(BaseModel):
    syntax: SyntaxLayerReport | None = None
    semantic: SemanticLayerReport | None = None
    shacl: SHACLLayerReport | None = None


class ValidationReport(BaseModel):
    contract_id: str
    contract_version: str
    validated_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    overall_status: OverallStatus
    layers: ValidationLayers = Field(default_factory=ValidationLayers)

    def is_passed(self) -> bool:
        return self.overall_status == OverallStatus.PASSED
