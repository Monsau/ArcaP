"""
Layer 2 — Semantic Logic Validator (OWL 2 Consistency).

Converts OOC semantics into OWL axioms, loads them into owlready2,
runs the HermiT (or Pellet) reasoner, and reports:
  - unsatisfiable classes
  - property characteristic contradictions
  - count of inferred triples
"""

from __future__ import annotations

from typing import Any

from ooc_guard.models.ooc import OOCDocument, OntologyClass, OntologyProperty
from ooc_guard.models.report import LayerStatus, SemanticLayerReport


# ---------------------------------------------------------------------------
# OWL axiom builder
# ---------------------------------------------------------------------------

def _build_owl_turtle(doc: OOCDocument) -> str:
    """
    Serialize the OOC semantics as a minimal OWL 2 Turtle document
    that can be loaded by owlready2 / rdflib.
    """
    contract = doc.ontology_contract
    base = contract.metadata.base_uri
    prefix = contract.metadata.id.split("-")[0]  # e.g. "olm" from "olm-core-spec"

    lines: list[str] = [
        f"@prefix {prefix}: <{base}> .",
        "@prefix owl: <http://www.w3.org/2002/07/owl#> .",
        "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
        "@prefix skos: <http://www.w3.org/2004/02/skos/core#> .",
        "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .",
        "",
        f"<{base}> a owl:Ontology .",
        "",
    ]

    def uri(curie_or_uri: str) -> str:
        """Expand CURIE to angle-bracket URI if needed."""
        if curie_or_uri.startswith("http"):
            return f"<{curie_or_uri}>"
        # keep as-is for prefixed names (rdflib handles them)
        return curie_or_uri

    # Classes
    for cls in contract.semantics.classes:
        lines.append(f"{uri(cls.uri)} a owl:Class ;")
        lines.append(f'    rdfs:label "{cls.definition}"@en ;')
        if cls.subclass_of:
            lines.append(f"    rdfs:subClassOf {uri(cls.subclass_of)} ;")
        if cls.equivalent_class:
            lines.append(f"    owl:equivalentClass {uri(cls.equivalent_class)} ;")
        for lang, lbl in cls.labels.items():
            lines.append(f'    skos:prefLabel "{lbl}"@{lang} ;')
        lines[-1] = lines[-1].rstrip(" ;") + " ."
        lines.append("")

    # Properties
    _char_map = {
        "owl:TransitiveProperty": "a owl:TransitiveProperty",
        "Transitive": "a owl:TransitiveProperty",
        "owl:SymmetricProperty": "a owl:SymmetricProperty",
        "Symmetric": "a owl:SymmetricProperty",
        "owl:IrreflexiveProperty": "a owl:IrreflexiveProperty",
        "Irreflexive": "a owl:IrreflexiveProperty",
        "owl:FunctionalProperty": "a owl:FunctionalProperty",
        "Functional": "a owl:FunctionalProperty",
        "owl:InverseFunctionalProperty": "a owl:InverseFunctionalProperty",
        "InverseFunctional": "a owl:InverseFunctionalProperty",
    }
    for prop in contract.semantics.properties:
        prop_type = prop.type.value if hasattr(prop.type, "value") else str(prop.type)
        chars = [_char_map[c] for c in prop.characteristics if c in _char_map]
        type_triple = f"a {prop_type}"
        all_types = ", ".join({type_triple, *chars}) if chars else type_triple
        lines.append(f"{uri(prop.uri)} {all_types} ;")
        if prop.domain:
            lines.append(f"    rdfs:domain {uri(prop.domain)} ;")
        if prop.range:
            lines.append(f"    rdfs:range {uri(prop.range)} ;")
        lines[-1] = lines[-1].rstrip(" ;") + " ."
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Reasoner integration
# ---------------------------------------------------------------------------

def _run_with_owlready2(turtle_src: str, reasoner: str) -> SemanticLayerReport:
    """Use owlready2 + HermiT/Pellet for OWL 2 consistency check."""
    try:
        import owlready2  # type: ignore[import]
        import tempfile, os
    except ImportError:
        return SemanticLayerReport(
            status=LayerStatus.ERROR,
            errors=["owlready2 is not installed. Run: pip install ooc-guard[owl]"],
        )

    errors: list[str] = []
    unsatisfiable: list[str] = []
    inferred = 0

    with tempfile.NamedTemporaryFile(suffix=".ttl", delete=False, mode="w", encoding="utf-8") as f:
        f.write(turtle_src)
        tmp_path = f.name

    try:
        onto = owlready2.get_ontology(f"file://{tmp_path}").load()
        with onto:
            try:
                if reasoner == "pellet":
                    owlready2.sync_reasoner_pellet(infer_property_values=True)
                else:
                    owlready2.sync_reasoner_hermit()
                inferred = len(list(onto.graph))
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Reasoner error: {exc}")
                return SemanticLayerReport(
                    status=LayerStatus.ERROR,
                    errors=errors,
                )

        for cls in onto.classes():
            if owlready2.Nothing in cls.equivalent_to:
                unsatisfiable.append(cls.name)

        satisfiable = sum(1 for _ in onto.classes()) - len(unsatisfiable)
        status = LayerStatus.PASSED if not unsatisfiable else LayerStatus.FAILED
        return SemanticLayerReport(
            status=status,
            reasoner=reasoner,
            satisfiable_classes=satisfiable,
            unsatisfiable_classes=len(unsatisfiable),
            unsatisfiable_names=unsatisfiable,
            inferred_triples=inferred,
            errors=errors,
        )
    finally:
        os.unlink(tmp_path)


def _run_with_rdflib(turtle_src: str) -> SemanticLayerReport:
    """
    Lightweight fallback using rdflib (no full reasoner).
    Checks for transitive+irreflexive contradictions via SPARQL ASK.
    """
    try:
        from rdflib import ConjunctiveGraph  # type: ignore[import]
        from rdflib.plugins.sparql import prepareQuery  # type: ignore[import]
    except ImportError:
        return SemanticLayerReport(
            status=LayerStatus.ERROR,
            errors=["rdflib is not installed. Run: pip install rdflib"],
        )

    g = ConjunctiveGraph()
    g.parse(data=turtle_src, format="turtle")
    inferred = len(g)
    errors: list[str] = []

    # Check: no property is both Transitive and Irreflexive with a self-loop
    ask_self_loop = """
    ASK {
        ?p a owl:TransitiveProperty, owl:IrreflexiveProperty .
        ?x ?p ?x .
    }
    """
    try:
        has_contradiction = bool(g.query(ask_self_loop))
        if has_contradiction:
            errors.append(
                "Contradiction: a property is both owl:TransitiveProperty and "
                "owl:IrreflexiveProperty and has a self-loop in data."
            )
    except Exception as exc:  # noqa: BLE001
        errors.append(f"SPARQL check error: {exc}")

    status = LayerStatus.FAILED if errors else LayerStatus.PASSED
    return SemanticLayerReport(
        status=status,
        reasoner="rdflib-sparql",
        inferred_triples=inferred,
        errors=errors,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_semantic(
    raw: dict[str, Any],
    reasoner: str = "hermit",
) -> SemanticLayerReport:
    """
    Run Layer 2 — OWL 2 semantic consistency check.

    Args:
        raw:      Parsed OOC dict (already passed Layer 1).
        reasoner: "hermit" | "pellet" | "rdflib" (lightweight fallback).
    """
    try:
        doc = OOCDocument.from_dict(raw)
    except Exception as exc:  # noqa: BLE001
        return SemanticLayerReport(
            status=LayerStatus.ERROR,
            errors=[f"Could not parse OOC document: {exc}"],
        )

    turtle_src = _build_owl_turtle(doc)

    if reasoner in ("hermit", "pellet"):
        return _run_with_owlready2(turtle_src, reasoner)
    return _run_with_rdflib(turtle_src)
