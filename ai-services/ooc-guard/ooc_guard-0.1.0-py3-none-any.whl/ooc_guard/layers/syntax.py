"""
Layer 1 — Syntax & OOC-Guard Compliance Validator.

Validates an OOC document against the Pydantic v2 models (structural
correctness, required fields, URI format, semver, label coverage).
"""

from __future__ import annotations

import re
from typing import Any

from pydantic import ValidationError

from ooc_guard.models.ooc import OOCDocument
from ooc_guard.models.report import (
    LayerStatus,
    SyntaxLayerReport,
    SyntaxViolation,
)


# ---------------------------------------------------------------------------
# Additional structural checks beyond Pydantic
# ---------------------------------------------------------------------------

_URI_PATTERN = re.compile(r"^https?://\S+$")
_CURIE_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_-]*:[A-Za-z]\S*$")


def _check_uris(doc: OOCDocument, violations: list[SyntaxViolation]) -> None:
    """Ensure every class/property uri is a valid CURIE or absolute URI."""
    contract = doc.ontology_contract
    for cls in contract.semantics.classes:
        if not _CURIE_PATTERN.match(cls.uri) and not _URI_PATTERN.match(cls.uri):
            violations.append(SyntaxViolation(
                field=f"semantics.classes[{cls.name}].uri",
                message=f"URI {cls.uri!r} is neither a valid CURIE nor an absolute URI.",
                value=cls.uri,
            ))
    for prop in contract.semantics.properties:
        if not _CURIE_PATTERN.match(prop.uri) and not _URI_PATTERN.match(prop.uri):
            violations.append(SyntaxViolation(
                field=f"semantics.properties[{prop.name}].uri",
                message=f"URI {prop.uri!r} is neither a valid CURIE nor an absolute URI.",
                value=prop.uri,
            ))


def _check_shape_targets(doc: OOCDocument, violations: list[SyntaxViolation]) -> None:
    """Ensure every SHACL shape target_class references a declared class URI."""
    contract = doc.ontology_contract
    declared_uris: set[str] = {c.uri for c in contract.semantics.classes}
    for shape in contract.data_integrity.shapes:
        if shape.target_class not in declared_uris:
            violations.append(SyntaxViolation(
                field=f"data_integrity.shapes[target_class={shape.target_class}]",
                message=(
                    f"Shape target_class {shape.target_class!r} does not match any "
                    "declared class URI in semantics.classes."
                ),
                value=shape.target_class,
            ))


def _check_immutable_attributes(doc: OOCDocument, violations: list[SyntaxViolation]) -> None:
    """Ensure immutable_attributes use recognised CURIE/URI format."""
    for attr in doc.ontology_contract.versioning_control.immutable_attributes:
        if not _CURIE_PATTERN.match(attr) and not _URI_PATTERN.match(attr):
            violations.append(SyntaxViolation(
                field="versioning_control.immutable_attributes",
                message=f"Immutable attribute {attr!r} is not a valid CURIE or URI.",
                value=attr,
            ))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_syntax(raw: dict[str, Any]) -> SyntaxLayerReport:
    """
    Run Layer 1 validation on a raw parsed OOC dict.

    Returns a SyntaxLayerReport. Status is FAILED if any violations are found
    or if Pydantic model validation raises.
    """
    violations: list[SyntaxViolation] = []
    errors: list[str] = []
    checks = 0

    # --- Pydantic structural validation ---
    try:
        doc = OOCDocument.from_dict(raw)
        checks += 1
    except ValidationError as exc:
        for err in exc.errors():
            violations.append(SyntaxViolation(
                field=".".join(str(loc) for loc in err["loc"]),
                message=err["msg"],
                value=err.get("input"),
            ))
        return SyntaxLayerReport(
            status=LayerStatus.FAILED,
            checks=checks,
            violations=violations,
            errors=errors,
        )
    except Exception as exc:  # noqa: BLE001
        errors.append(f"Unexpected parse error: {exc}")
        return SyntaxLayerReport(
            status=LayerStatus.ERROR,
            checks=checks,
            violations=violations,
            errors=errors,
        )

    # --- Additional structural checks ---
    checks += 1
    _check_uris(doc, violations)
    checks += 1
    _check_shape_targets(doc, violations)
    checks += 1
    _check_immutable_attributes(doc, violations)

    status = LayerStatus.PASSED if not violations else LayerStatus.FAILED
    return SyntaxLayerReport(
        status=status,
        checks=checks,
        violations=violations,
        errors=errors,
    )
