"""
Layer 3 — SHACL Data Compliance Validator.

Converts OOC data_integrity.shapes into a SHACL graph (Turtle),
then validates a target RDF data graph using PySHACL.
"""

from __future__ import annotations

from typing import Any

from ooc_guard.models.ooc import OOCDocument, SHACLConstraint, SHACLShape
from ooc_guard.models.report import (
    LayerStatus,
    SHACLLayerReport,
    SHACLViolation,
)


# ---------------------------------------------------------------------------
# SHACL graph builder
# ---------------------------------------------------------------------------

def _build_shacl_turtle(doc: OOCDocument) -> str:
    """
    Convert OOC data_integrity.shapes into a SHACL Turtle document.
    """
    base = doc.ontology_contract.metadata.base_uri

    lines: list[str] = [
        "@prefix sh:   <http://www.w3.org/ns/shacl#> .",
        "@prefix xsd:  <http://www.w3.org/2001/XMLSchema#> .",
        "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
        "@prefix owl:  <http://www.w3.org/2002/07/owl#> .",
        f"@base <{base}> .",
        "",
    ]

    def uri(s: str) -> str:
        if s.startswith("http"):
            return f"<{s}>"
        return s

    for shape in doc.ontology_contract.data_integrity.shapes:
        shape_id = shape.id or f"Shape_{shape.target_class.replace(':', '_')}"
        severity = shape.severity.value if hasattr(shape.severity, "value") else str(shape.severity)
        lines += [
            f"<#{shape_id}>",
            "    a sh:NodeShape ;",
            f"    sh:targetClass {uri(shape.target_class)} ;",
            f"    sh:severity {severity} ;",
        ]

        for i, c in enumerate(shape.constraints):
            is_last = i == len(shape.constraints) - 1
            prop_block = _constraint_to_shacl(c, severity)
            terminator = "." if is_last else ";"
            lines.append(f"    sh:property [")
            for line in prop_block:
                lines.append(f"        {line}")
            lines.append(f"    ] {terminator}")

        lines.append("")

    return "\n".join(lines)


def _constraint_to_shacl(c: SHACLConstraint, default_severity: str) -> list[str]:
    """Serialize one SHACLConstraint as a sh:PropertyShape block (lines)."""
    lines: list[str] = [f"sh:path {c.property} ;"]

    if c.min_count is not None:
        lines.append(f"sh:minCount {c.min_count} ;")
    if c.max_count is not None:
        lines.append(f"sh:maxCount {c.max_count} ;")
    if c.datatype:
        lines.append(f"sh:datatype {c.datatype} ;")
    if c.pattern:
        lines.append(f'sh:pattern "{c.pattern}" ;')
    if c.in_values:
        values = " ".join(f'"{v}"' for v in c.in_values)
        lines.append(f"sh:in ({values}) ;")
    if c.class_:
        lines.append(f"sh:class {c.class_} ;")
    if c.language_in:
        langs = " ".join(f'"{lg}"' for lg in c.language_in)
        lines.append(f"sh:languageIn ({langs}) ;")
    if c.message:
        lines.append(f'sh:message "{c.message}" ;')

    lines.append(f"sh:severity {default_severity} ;")

    # Remove trailing semicolons from last item
    lines[-1] = lines[-1].rstrip(" ;")
    return lines


# ---------------------------------------------------------------------------
# PySHACL runner
# ---------------------------------------------------------------------------

def _run_pyshacl(
    shacl_graph_ttl: str,
    data_graph_source: str | None,
    strict: bool,
) -> SHACLLayerReport:
    try:
        import pyshacl  # type: ignore[import]
    except ImportError:
        return SHACLLayerReport(
            status=LayerStatus.ERROR,
            errors=["pyshacl is not installed. Run: pip install ooc-guard[shacl]"],
        )

    if data_graph_source is None:
        # No data graph provided — validate shapes syntax only
        return SHACLLayerReport(
            status=LayerStatus.PASSED,
            shapes_evaluated=1,
        )

    try:
        conforms, results_graph, results_text = pyshacl.validate(
            data_graph=data_graph_source,
            shacl_graph=shacl_graph_ttl,
            data_graph_format="turtle",
            shacl_graph_format="turtle",
            inference="rdfs",
            abort_on_first=False,
        )
    except Exception as exc:  # noqa: BLE001
        return SHACLLayerReport(
            status=LayerStatus.ERROR,
            errors=[f"PySHACL execution error: {exc}"],
        )

    violations: list[SHACLViolation] = []
    warnings_count = 0
    infos_count = 0
    violations_count = 0

    # Parse results graph for individual violations
    try:
        from rdflib import Graph, Namespace  # type: ignore[import]
        from rdflib.namespace import RDF  # type: ignore[import]

        SH = Namespace("http://www.w3.org/ns/shacl#")
        rg = Graph()
        rg.parse(data=results_graph.serialize(format="turtle"), format="turtle")

        for result in rg.subjects(RDF.type, SH.ValidationResult):
            sev_node = rg.value(result, SH.resultSeverity)
            severity = str(sev_node).split("#")[-1] if sev_node else "Violation"
            node = str(rg.value(result, SH.focusNode) or "")
            path = str(rg.value(result, SH.resultPath) or "")
            msg = str(rg.value(result, SH.resultMessage) or "")
            source = str(rg.value(result, SH.sourceShape) or "")

            v = SHACLViolation(
                shape_id=source,
                target_node=node,
                property=path or None,
                severity=severity,
                message=msg,
            )
            violations.append(v)
            if severity == "Violation":
                violations_count += 1
            elif severity == "Warning":
                warnings_count += 1
            else:
                infos_count += 1
    except Exception:  # noqa: BLE001
        pass  # fall back to conforms flag

    failed = not conforms or (strict and warnings_count > 0)
    status = LayerStatus.FAILED if failed else LayerStatus.PASSED

    return SHACLLayerReport(
        status=status,
        violations=violations_count,
        warnings=warnings_count,
        infos=infos_count,
        details=violations,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_shacl(
    raw: dict[str, Any],
    data_graph_source: str | None = None,
    strict: bool = False,
) -> SHACLLayerReport:
    """
    Run Layer 3 — SHACL data compliance check.

    Args:
        raw:               Parsed OOC dict (already passed Layer 1).
        data_graph_source: Path or Turtle string of the RDF data graph.
                           If None, only shape syntax is verified.
        strict:            Treat sh:Warning results as failures.
    """
    try:
        doc = OOCDocument.from_dict(raw)
    except Exception as exc:  # noqa: BLE001
        return SHACLLayerReport(
            status=LayerStatus.ERROR,
            errors=[f"Could not parse OOC document: {exc}"],
        )

    if not doc.ontology_contract.data_integrity.shapes:
        return SHACLLayerReport(
            status=LayerStatus.PASSED,
            shapes_evaluated=0,
        )

    shacl_ttl = _build_shacl_turtle(doc)

    data_src: str | None = None
    if data_graph_source is not None:
        # Accept file path or raw Turtle string
        if data_graph_source.strip().startswith("@") or "\n" in data_graph_source:
            data_src = data_graph_source
        else:
            try:
                with open(data_graph_source, encoding="utf-8") as fh:
                    data_src = fh.read()
            except OSError as exc:
                return SHACLLayerReport(
                    status=LayerStatus.ERROR,
                    errors=[f"Cannot read data graph file: {exc}"],
                )

    report = _run_pyshacl(shacl_ttl, data_src, strict=strict)
    report.shapes_evaluated = len(doc.ontology_contract.data_integrity.shapes)
    return report
