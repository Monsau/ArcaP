"""
OOC-Guard CLI — Typer-based command-line interface.

Usage:
    ooc-guard validate [OPTIONS] CONTRACT_FILE
    ooc-guard export-inferred [OPTIONS] CONTRACT_FILE
    ooc-guard promote [OPTIONS] CONTRACT_GLOB
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from ooc_guard.validator import validate
from ooc_guard.models.report import OverallStatus

app = typer.Typer(
    name="OOC-Guard",
    help="The Logic Firewall for Industry 4.0 Ontologies — OOC-Guard v1.0.0",
    add_completion=False,
)
console = Console()
err_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _status_icon(status: str) -> str:
    return "[green]✔ PASSED[/green]" if "PASSED" in status else "[red]✘ FAILED[/red]"


def _print_report_table(report) -> None:
    table = Table(
        title=f"OOC-Guard — {report.contract_id} v{report.contract_version}",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("Layer", style="bold")
    table.add_column("Status", justify="center")
    table.add_column("Details")

    if report.layers.syntax:
        s = report.layers.syntax
        details = f"{s.checks} checks · {len(s.violations)} violations"
        table.add_row("1 · Syntax (OOC-Guard)", _status_icon(s.status), details)

    if report.layers.semantic:
        s = report.layers.semantic
        details = (
            f"Reasoner: {s.reasoner} · "
            f"Satisfiable: {s.satisfiable_classes} · "
            f"Unsatisfiable: {s.unsatisfiable_classes} · "
            f"Inferred triples: {s.inferred_triples}"
        )
        table.add_row("2 · Semantic (OWL 2)", _status_icon(s.status), details)

    if report.layers.shacl:
        s = report.layers.shacl
        details = (
            f"Shapes: {s.shapes_evaluated} · "
            f"Violations: {s.violations} · "
            f"Warnings: {s.warnings}"
        )
        table.add_row("3 · Data Compliance (SHACL)", _status_icon(s.status), details)

    console.print(table)
    console.print(
        f"\n[bold]Overall:[/bold] {_status_icon(report.overall_status)}\n"
    )


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@app.command("validate")
def cmd_validate(
    contract_file: Path = typer.Argument(..., help="Path to the OOC YAML/JSON file."),
    layer: str = typer.Option("all", help="Layer to run: all | syntax | semantic | shacl"),
    data: Optional[Path] = typer.Option(None, help="RDF data graph (.ttl) for SHACL layer."),
    reasoner: str = typer.Option("hermit", help="OWL reasoner: hermit | pellet | rdflib"),
    report_format: str = typer.Option("json", "--report-format", help="Output format: json | text"),
    output: Optional[Path] = typer.Option(None, help="Output directory for report files."),
    strict: bool = typer.Option(False, help="Treat sh:Warning as failure."),
    verbose: bool = typer.Option(False, help="Verbose output."),
) -> None:
    """Validate an OOC contract through the three-layer OOC-Guard pipeline."""

    if not contract_file.exists():
        err_console.print(f"[red]Error:[/red] File not found: {contract_file}")
        raise typer.Exit(1)

    if verbose:
        console.print(f"[cyan]Validating:[/cyan] {contract_file}")

    report = validate(
        contract_path=contract_file,
        layer=layer,
        data_graph=str(data) if data else None,
        reasoner=reasoner,
        strict=strict,
    )

    # --- Console output ---
    if report_format == "text" or verbose:
        _print_report_table(report)

    # --- File output ---
    if output:
        output.mkdir(parents=True, exist_ok=True)
        out_file = output / f"{report.contract_id}-validation.json"
        out_file.write_text(
            report.model_dump_json(indent=2), encoding="utf-8"
        )
        if verbose:
            console.print(f"[dim]Report written to:[/dim] {out_file}")

    # --- Stdout JSON (default) ---
    if report_format == "json" and not output:
        print(report.model_dump_json(indent=2))

    # --- Exit code ---
    if report.overall_status != OverallStatus.PASSED:
        if not verbose and report_format != "text":
            _print_report_table(report)

        # Print violation details
        if report.layers.syntax and report.layers.syntax.violations:
            err_console.print("\n[red bold]Syntax violations:[/red bold]")
            for v in report.layers.syntax.violations:
                err_console.print(f"  [red]✘[/red] [{v.field}] {v.message}")

        if report.layers.semantic and report.layers.semantic.unsatisfiable_names:
            err_console.print("\n[red bold]Unsatisfiable classes:[/red bold]")
            for name in report.layers.semantic.unsatisfiable_names:
                err_console.print(f"  [red]✘[/red] {name}")

        if report.layers.shacl and report.layers.shacl.details:
            err_console.print("\n[red bold]SHACL violations:[/red bold]")
            for v in report.layers.shacl.details[:20]:
                err_console.print(
                    f"  [red]✘[/red] [{v.severity}] Node: {v.target_node} "
                    f"| Path: {v.property} | {v.message}"
                )

        raise typer.Exit(1)


@app.command("export-inferred")
def cmd_export_inferred(
    contract_file: Path = typer.Argument(..., help="Path to the OOC YAML/JSON file."),
    format_out: str = typer.Option("turtle", "--format", help="Output RDF format: turtle | json-ld"),
    output: Optional[Path] = typer.Option(None, help="Output file path."),
    reasoner: str = typer.Option("rdflib", help="Reasoner: hermit | pellet | rdflib"),
) -> None:
    """Export inferred OWL triples from a validated OOC contract."""
    from ooc_guard.layers.semantic import _build_owl_turtle
    from ooc_guard.models.ooc import OOCDocument
    import yaml as _yaml

    if not contract_file.exists():
        err_console.print(f"[red]Error:[/red] File not found: {contract_file}")
        raise typer.Exit(1)

    with contract_file.open(encoding="utf-8") as fh:
        raw = _yaml.safe_load(fh)

    doc = OOCDocument.from_dict(raw)
    turtle = _build_owl_turtle(doc)

    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(turtle, encoding="utf-8")
        console.print(f"[green]Exported:[/green] {output}")
    else:
        print(turtle)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
