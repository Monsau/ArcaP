"""OOC-Guard — The Logic Firewall for Industry 4.0 Ontologies."""

__version__ = "0.1.0"
